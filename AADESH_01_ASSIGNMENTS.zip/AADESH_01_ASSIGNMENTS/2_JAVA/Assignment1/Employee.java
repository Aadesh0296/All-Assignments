 class Employee {
	  
	 public static void main(String[] args) {
	
		 int eid = Integer.parseInt(args[0]);
		 int age = Integer.parseInt(args[1]);
		 int hrs = Integer.parseInt(args[2]);
		 double rate = Double.parseDouble(args[3]);

		 Income data = new Income(eid,age,hrs,rate);
		 System.out.printf("Employee Net Income: %.2f %n", data.getNetIncome());
	   //      System.out.printf("good manner of employee:  ",e.printEmployee());

	 }
	// public void printEmployee(String[] args){
	//		 System.out.println("Employee is good manner.");
	//	 }

 }	
