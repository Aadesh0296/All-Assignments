class Income{

	private int empid;
	private int age;
	private int hours;
	private double rate;


	public Income(int eid, int a, int hr, double rt){
	
		empid = eid;
		age = a;
		hours = hr;
		rate = rt;

	}

	public double getNetIncome() {
	
	       	int overtime = hours > 180 ? (hours-180)*100 : 0;
		
	//	double overtime = hours-180 * extra;

		/*if(hours > 180)
		{
			int overtime = (hours - 180)*100; 
		}
		else
			 overtime = 0;*/

	 return ((180) * rate + overtime);
	
	
	
	}
		

}
