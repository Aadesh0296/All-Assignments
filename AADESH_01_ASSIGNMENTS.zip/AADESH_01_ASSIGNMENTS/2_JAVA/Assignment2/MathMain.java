class MathMain{
public static void main(String[] args){
	int number;
	int number2;
	number = Integer.parseInt(args[0]);
	number2 = Integer.parseInt(args[1]);
	MathUtility mu=new MathUtility(number);
	MathUtility mu1=new MathUtility(number,number2);
	mu.isOdd();
	mu.squareOfNumber();
	mu.cubeOfNumber();
	mu.primeNumber();
	mu.reverseNumber();
	mu1.countPrimeNumber();
	}
}
