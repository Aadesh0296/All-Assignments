
	private int number;
	private int number2;
	MathUtility(int n){
		number = n;
	}
	MathUtility(int n,int m){
		number = n;
		number2 = m;
	}

	public void isOdd(){	
		if (number % 2 != 0 )
			System.out.printf("The Number %d is Odd%n",number);
		else
			System.out.printf("The Number %d is Even%n",number);
	}

	public void squareOfNumber(){
		System.out.printf("The Square of %d is : %d%n",number,number*number);	
	}

	public void cubeOfNumber(){
		System.out.printf("The Cube Of %d is   : %d%n",number,number*number*number);
	}

	public void primeNumber(){
		int i;
		boolean prime =false;

		for (i=2;i<=number/2;++i){
			if (number % i == 0){
				prime = true;	
				System.out.printf("The Number %d is not a prime number%n",number);
				break;
			}
		}
		if(prime == false)
		System.out.printf("The Number %d is a prime number%n",number);
				
	}

	public void countPrimeNumber(){
		int i;
		int j;
		int count = 0;
		//boolean prime =false;
		for (i=number;i<=number2;++i){
			for(j=2;j<=number2/2;++j){
				if(i%j == 0){
			    //      count += 1;
				}
			}
		count += 1;
		}
		System.out.printf("Total prime numbers between %d and %d are %d%n",number,number2,count);
	}




	public void reverseNumber(){
		int temp = number;
		int sum = 0;
		int count = 0;
		do{
			sum = sum * 10 + temp % 10;
			temp = temp / 10;
			count +=1;
		}
		while(temp>0);
			System.out.printf("The reverse of number %d is : %d%n",number,sum);
			System.out.printf("Total Digits in number are %d%n",count);
	}

}
