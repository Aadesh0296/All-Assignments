package finance;

interface Taxable {
	double GST(double emi);

}

