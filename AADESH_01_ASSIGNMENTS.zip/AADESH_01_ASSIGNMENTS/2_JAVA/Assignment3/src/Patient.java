package bill;

public class Patient{

	private int id;
	private int bedtype;
	private int days;
	
	public Patient(int pid, int btype, int d){
		
		id = pid;
		bedtype = btype;
		days = d;
	
	}

	public int getPricePerDay(){
	
		int price = 0;
	
		if(bedtype == 1)
			price = 500;
	
		if(bedtype == 2)
			price = 350;
		
		if(bedtype == 3)
			price = 200;
		
		return  price;
	}

	public double getBillAmount() {
	
		 double Amount;
		
		return  Amount = getPricePerDay() * days;
	
	
	
	}
	public double inHousePatient(){
	
	  double Amount = getBillAmount();
	  double discount = Amount > 5000 ? 0.05 : 0;

	 return (Amount - (discount * Amount));	  
	
	
	}
}
