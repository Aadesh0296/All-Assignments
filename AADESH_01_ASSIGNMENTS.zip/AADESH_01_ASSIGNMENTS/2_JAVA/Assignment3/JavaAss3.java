
import bill.Patient;

class JavaAss3{
	public static void main(String[] args) {

		//String name = String.parseStr(args[0]);

		int pid = Integer.parseInt(args[0]);

		int btype = Integer.parseInt(args[1]);

		int d = Integer.parseInt(args[2]);

		Patient data = new Patient(pid,btype,d);

		System.out.printf("Hello Patient%n");
		
		System.out.printf("Your Billing Amount is %f %n", data.getBillAmount());

		System.out.printf("Your Billing Amount for In House Patient is %f %n", data.inHousePatient());

		}
}
