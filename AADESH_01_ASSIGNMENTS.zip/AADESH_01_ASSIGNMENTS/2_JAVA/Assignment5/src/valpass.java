package sequencetype;

public class valpass{
	public static Sequence linear(){
	var first = new LinearSequence();
	return first;
}
	public static Sequence power(){
	var second = new PowerSequence();
	return second;
}
	private valpass(){}
}
