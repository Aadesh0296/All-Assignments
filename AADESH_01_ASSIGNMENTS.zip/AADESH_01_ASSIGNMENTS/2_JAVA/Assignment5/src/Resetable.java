package sequencetype;

public interface Resetable{

   void Reset();

}
