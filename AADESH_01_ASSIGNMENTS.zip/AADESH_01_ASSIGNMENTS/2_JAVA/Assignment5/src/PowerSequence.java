package sequencetype;

final class PowerSequence extends Sequence implements Resetable{

     private double factor;

     public PowerSequence(){
       current = 1;
       factor = 3;
     }

     public double Next(){
      double term = current;
      current *=factor;
       return term;
     }

    public void Reset(){
     current = 1;
     }

}
     
