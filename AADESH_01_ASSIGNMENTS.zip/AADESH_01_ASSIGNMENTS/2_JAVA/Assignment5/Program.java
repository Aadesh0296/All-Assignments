import sequencetype.*;

class Program{

   public static double compute(Sequence seq,int count){
    
    if(seq instanceof Resetable r){
       r.Reset();
   }
     return seq.Sum(count)/count;

   }


  public static void main(String[] args){

    Sequence first = valpass.linear();
    Sequence second = valpass.power();
   
    System.out.printf("Linear Sequence Average:%.2f%n",compute(first,8));
    System.out.printf("Power Sequense Average:%.2f%n",compute(second,8));
}

}
