static class Worker
{
    public static bool Dowork(int n)
    {
        if(n %2 ==0)
            return true;
        return false;    
    }
}

