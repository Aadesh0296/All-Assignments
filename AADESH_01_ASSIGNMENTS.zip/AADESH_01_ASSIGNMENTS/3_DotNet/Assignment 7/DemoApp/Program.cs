﻿using var s = new IsOddEven();
 
Thread child = new Thread(() =>
{
    Console.
}


);

class IsOddEven
{
    public int number { get; set; }

    public 
}