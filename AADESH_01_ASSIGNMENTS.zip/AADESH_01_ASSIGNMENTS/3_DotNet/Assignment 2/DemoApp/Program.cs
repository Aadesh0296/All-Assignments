﻿using bill.hospital;

class Program 
{
    public static void Main(string[] args)
    {
        int PatientId = int.Parse(args[0]);
        string Name = args[1];
        int BedType = int.Parse(args[2]);
        int NoOfdays = int.Parse(args[3]);
    
        var regular = new Patient(PatientId, Name, BedType, NoOfdays);
        var inhouse = new InHousePatient(PatientId, Name, BedType, NoOfdays);
        Console.WriteLine("--------------------------------------------------------");

        Console.WriteLine("Patient Id = {0}",PatientId);
        Console.WriteLine("Enter Patient's Name = {0}",Name);
        Console.WriteLine("Bed Type = {0}",BedType);
        Console.WriteLine("Number Of Days = {0}\n",NoOfdays);
        Console.WriteLine("--------------------------------------------------------");

        Console.WriteLine("Your total billing Amount = {0}",regular.GetBillAmount());
        Console.WriteLine("Including Discount for InHouse Patient Final Billing Amount = {0}",inhouse.GetBillAmount());    
    }
}