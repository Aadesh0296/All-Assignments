namespace bill.hospital;

class InHousePatient : Patient
{
    public double Discount {get; set;}

    public InHousePatient(int PatientId, string Name, int BedType, int NoOfdays)
    {
        base.PatientId = PatientId;
        base.PatientName = Name;
        base.BedType = BedType;
        base.NoOfdays = NoOfdays;
              
    }

    public override double GetBillAmount() {
		
        double amount = base.GetBillAmount();
		
        double Discount = amount >= 5000 ? 0.05 : 0;
		
		return amount- (amount * Discount);
	}
}