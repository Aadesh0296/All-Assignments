namespace finance;

interface ITaxable {
	double GST(double emi);

}

