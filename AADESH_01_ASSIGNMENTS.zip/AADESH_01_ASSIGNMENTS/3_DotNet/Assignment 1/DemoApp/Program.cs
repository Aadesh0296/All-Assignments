﻿using MathUtility;
class BasicMaths 
{		
	public static void Main(string[] args)
	{
		int first = int.Parse(args[0]);
		int second = int.Parse(args[1]);

		if(MathUtil.IsEven(first))
			Console.WriteLine("{0} is an Even Number",first);
		else 
			Console.WriteLine("{0} is not an Even Number",first);

		if(MathUtil.IsOdd(first))
			Console.WriteLine("{0} is an Odd Number",first);
		else 
			Console.WriteLine("{0} is not an Odd Number",first);

		
		if(MathUtil.IsPrime(first))
			Console.WriteLine("{0}  is a Prime Number",first);
		else 
			Console.WriteLine("{0}  is not a Prime Number",first);

		if(first > second)
			Console.WriteLine("Total no of primes from {0} to {1} are : {2} ",first,second,MathUtil.CountPrimes(second,first));
		else
			Console.WriteLine("Total no of primes from {0} to {1} are : {2} ",first,second,MathUtil.CountPrimes(first,second));

			
		Console.WriteLine("Reverse order of {0} is {1} ",first,MathUtil.ReverseNum(first));

		Console.WriteLine("Number of Digits in {0} is {1} ",first,MathUtil.CountDigits(first));


	}	
}
