﻿using banner;

class Program
{
    public static double BannerPrice(RegularBanner info, int copies)
    {
        float rate = copies < 5 ? 0.08f : 0.75f;
        return copies * rate * info.Area();
    }
    public static void Main(string[] args)
    {
        int copies = int.Parse(args [0]);
        float width = float.Parse(args[1]);
        float height = float.Parse(args[2]);
        float radius = float.Parse(args[3]);

        var reg = new RegularBanner(width, height);
        var cur = new CurvedBanner(width, height, radius);
        Console.WriteLine("Regular banner price for {0} banners = {1:0.00}", copies,BannerPrice(reg, copies));
        Console.WriteLine("Curved banner price for {0} banners = {1:0.00}", copies,BannerPrice(cur, copies));

    }
}