namespace banner;
class RegularBanner
{
    public float width { get; set; }
    public float height { get; set; }

    public RegularBanner()
    {
        width = 0;
        height = 0;
    }
    public RegularBanner(float width, float height)
    {
        this.width = width;
        this.height = height;

    }

    public virtual double Area()
    {
        return width * height;
    }

}