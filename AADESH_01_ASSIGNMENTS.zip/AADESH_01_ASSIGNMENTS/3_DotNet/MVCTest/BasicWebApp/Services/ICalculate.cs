namespace BasicWebApp.Services;

public interface ICalculate
{
    double SiCalculate(double Principal, int Rate, int Years);
}